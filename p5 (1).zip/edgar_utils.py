import pandas as pd
import re
import edgar_utils
import netaddr
from bisect import bisect

ips = pd.read_csv("ip2location.csv")

def lookup_region(ip_address):
    global ips
    ip_address = re.sub(r"[a-zA-Z]", "0", ip_address)
    ip_address = int(netaddr.IPAddress(ip_address))
    idx = bisect(ips["low"], ip_address)
    return ips.iloc[idx-1]["region"]

class Filing:
    def __init__(self, html):
        self.dates = re.findall(r"19[0-9]{2}-[0-9][0-9]-[0-3][0-9]|20[0-9]{2}-[0-9][0-9]-[0-3][0-9]", html)   
        
        self.sic = None
        for val in re.findall(r"(?<=SIC=)[0-9]+", html):
            if val != "":
                self.sic = int(val)
                break


        addresses = []
        for addr_html in re.findall(r'<div class="mailer">([\s\S]+?)</div>', html):
            lines = []
            for line in re.findall(r'<span class="mailerAddress">([\s\S]+?)</span>', addr_html):
                    lines.append(line.strip())
            if "\n".join(lines) != "":
                addresses.append("\n".join(lines))
        self.addresses = addresses

    def state(self):
        for addr in self.addresses:
            if addr != "":
                addr_state = re.findall(r'[A-Z]{2}\s[0-9]{5}', addr)
                if addr_state != []:
                    return addr_state[0][0:2]
                else:
                    continue

                
        return None

