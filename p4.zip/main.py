# project: p4
# submitter: ejhickey3
# partner: none
# hours: 6

import sys
import pandas as pd
from flask import Flask, request, jsonify, Response
import re
import time
import matplotlib
import matplotlib.pyplot as plt
matplotlib.use('Agg')
import io



# data taken from: https://www.baseball-reference.com/teams/NYY/batteam.shtml

app = Flask(__name__)
df = pd.read_csv("main.csv")
counter = 0
clicks = {"A": 0, "B": 0}
visitors = {}

@app.route('/')
def home():
    global counter
    counter += 1 
    if counter <= 10:
        if (counter % 2) == 0:
            with open("indexA.html") as f:
                html = f.read()
        if (counter % 2) != 0:
            with open("indexB.html") as f:
                html = f.read()
            
    if counter > 10:
        if clicks["A"] > clicks["B"]:
            with open("indexA.html") as f:
                html = f.read()
            
        if clicks["B"] > clicks["A"]:
            with open("indexB.html") as f:
                html = f.read()
            
    return html

@app.route('/SOpABpYR.svg')
def plot1():
    fig, ax = plt.subplots(figsize=(3,2))
    yr_so_per_ab = []
    for i in range(len(df)):
        yr_so_per_ab.append(df.iloc[i]["SO"]/df.iloc[i]["AB"])
    query =  request.args.get("bins", "10")
    pd.Series(yr_so_per_ab).plot.hist(ax=ax, bins= int(query) )
    ax.set_xlabel("SO per AB in a Given Year")
    ax.set_ylabel("Freq of SO per AB")
    plt.tight_layout()

    f = io.StringIO()
    fig.savefig(f, format="svg")
    plt.close()
    return Response(f.getvalue(), headers={"Content-Type":"image/svg+xml"})


@app.route('/HR_YR/AB.svg')
def plot2():
    fig, ax = plt.subplots(figsize=(3,2))
    df2= df[["2B", "3B", "HR"]]
    df2.plot.line(ax=ax)
    ax.set_xlabel("Years Since 2022")
    ax.set_ylabel("Amount")
    plt.tight_layout()

    f = io.StringIO()
    fig.savefig(f, format="svg")
    plt.close()
    return Response(f.getvalue(), headers={"Content-Type":"image/svg+xml"})





@app.route('/donate.html')
def donate_home():
    site = request.args.get("from", "A")
    clicks[site] += 1 
    with open("donate.html") as f:
        html = f.read()

    return html


@app.route('/browse.html')
def yankee_handler():
    table = df.to_html()
    table = "<h1>Yankee Stats<h1><html><body style='background-color:SlateBlue;'>{}><\body><html>".format(table)        
    return table


@app.route('/browse.json')
def data_handler():
    json_stats = df.to_dict("index")
    json_stats =  jsonify(json_stats)
    visitor = request.remote_addr
    global visitors
    if visitor not in visitors:
        visitors[visitor] = time.time()
        return json_stats
    else:
        last_visit = visitors[visitor]
        new_visit = time.time()
        amnt_betw = new_visit - last_visit
        visitors[visitor] = new_visit
        if amnt_betw <= 60:
            return Response("<b> Too soon, come back later!</b>", status=429, headers={"Retry-After":"1 minute"})
        else: 
            return json_stats
        
@app.route('/visitors.json')
def visit_browse():
    return "<body>{}</body>".format(list(visitors.keys()))


emails = []
@app.route('/email', methods=["POST"])
def email():
    email = str(request.data, "utf-8")
    if len(re.findall(r"(^\w+@{1}\w+\.(com|edu|org|net))", email)) > 0 : # 1
        emails.append(email)
        with open("emails.txt", "a") as f: # open file in append mode
            f.write(email + "\n") # 2
        return jsonify(f"thanks, you're subscriber number {len(emails)}!")
    return jsonify(f"Please enter a valid email address.") # 3


if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=True, threaded=False) # don't change this line!
