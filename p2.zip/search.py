# class Graph():
#     def __init__(self):
#     self.nodes = {}
#     self.visited = set()
    
#     def node(self, name):
#         node = Node(name)
#         self.nodes[name] = node
#         node.graph
             
#     def edge(self, src, dst)
             
             
             
#     def search(self, source, destination):
#              self.visited.clear()
#              return self.nodes[source].search(self.nodes[destination])



class Node():
    def __init__(self, key):
        self.key = key
        self.values = []
        self.left = None
        self.right = None
        
    def __len__(self):
        size = len(self.values)
        if self.left != None:
            size += len(self.left.values)
        if self.right != None:
            size += len(self.right.values)
        return size
    


       #     lookup method (takes key)
    # if key matches my key, return my values
    # if key is less than my key and I have a left child
    #     call lookup on my left child and return what it returns
    # if key is greater than my key and I have a right child
    #     call lookup on my right child and return what it returns
    # otherwise return an empty list
    
    def lookup(self, key):
        if key == self.key:
            return self.values
        if key < self.key:
            if self.left != None:
                return self.left.lookup(key)
        if key > self.key:
            if self.right != None:
                return self.right.lookup(key)
        return []


 
    def height(self):
        
        #left subtree, x right subtree,y my height= max(x,y)+1
        if self.left == None:
            x = 0
        else:
            x = self.left.height()
        if self.right == None:
            y = 0
        else:
            y = self.right.height()
        return max(x,y) + 1
    
class BST():
    def __init__(self):
        self.root = None


    def __dump(self, node):
        if node == None:
            return
        self.__dump(node.right)            # 1
        print(node.key, ":", node.values)  # 2
        self.__dump(node.left)             # 3

    def dump(self):
        self.__dump(self.root)
        
    def __getitem__(self, key):
        return self.root.lookup(key)
    

        
    def search(self, key):
        if self.key == key:
            return True
        for val in curr.values:
            if val.search(key):
                return True
        return False

    
    def add(self, key, val):
        if self.root == None:
            self.root = Node(key)

        curr = self.root
        while True:
            if key < curr.key:
                # go left
                if curr.left == None:
                    curr.left = Node(key)
                curr = curr.left
            elif key > curr.key:
                 # go right
                if curr.right == None:
                    curr.right = Node(key)
                curr = curr.right
            else:
                # found it!
                assert curr.key == key
                break

        curr.values.append(val)
        
        

        