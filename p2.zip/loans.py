race_lookup = {
    "1": "American Indian or Alaska Native",
    "2": "Asian",
    "21": "Asian Indian",
    "22": "Chinese",
    "23": "Filipino",
    "24": "Japanese",
    "25": "Korean",
    "26": "Vietnamese",
    "27": "Other Asian",
    "3": "Black or African American",
    "4": "Native Hawaiian or Other Pacific Islander",
    "41": "Native Hawaiian",
    "42": "Guamanian or Chamorro",
    "43": "Samoan",
    "44": "Other Pacific Islander",
    "5": "White",
}

import json
import csv
import pandas as pd
from zipfile import ZipFile, ZIP_DEFLATED
from io import TextIOWrapper

class Applicant:
    def __init__(self, age, race):
        self.age = age
        self.race = set()
        for r in race:
            if r not in race_lookup:
                continue
            self.race.add(race_lookup[r])
            

    def __repr__(self):
        rep = f"Applicant('{self.age}', {str(list(self.race))})"
        return rep
    
    def lower_age(self):
        age_nums = []
        for val in self.age:
            if val.isdigit() == True:
                age_nums.append(val)
        return int(age_nums[0] + age_nums[1])
    
    def __lt__(self, other):
        return self.lower_age() < other.lower_age()
    
class Loan:
    def __init__(self, values):
        if values["loan_amount"][0].isdigit() == True:
            self.loan_amount = float(values["loan_amount"])
        elif values["loan_amount"][0].isdigit() != True:
            self.loan_amount = float(-1)
                
        if values["property_value"][0].isdigit() == True:
            self.property_value = float(values["property_value"])
        elif values["property_value"][0].isdigit() != True:
            self.property_value = float(-1)
                
        if values["interest_rate"][0].isdigit() == True:
            self.interest_rate = float(values["interest_rate"])
        elif values["interest_rate"][0].isdigit() != True:
            self.interest_rate = float(-1)
            
        self.applicant_age = values["applicant_age"]
        self.coapplicant_age = values["co-applicant_age"]
         
        self.appl_races = [values["applicant_race-1"], values["applicant_race-2"], values["applicant_race-3"], values["applicant_race-4"], values["applicant_race-5"]]
        
        if self.coapplicant_age == "9999":
            self.applicants = [Applicant(self.applicant_age, self.appl_races)]
        self.coappl_races = [values["co-applicant_race-1"], values["co-applicant_race-2"], values["co-applicant_race-3"], values["co-applicant_race-4"], values["co-applicant_race-5"]]
        
        if self.coapplicant_age != "9999":
            self.applicants = [Applicant(self.applicant_age, self.appl_races), Applicant(self.coapplicant_age, self.coappl_races)]
            
    def __str__(self):
        statement = f"<Loan: {self.interest_rate}% on ${self.property_value} with {len(self.applicants)} applicant(s)>"
        return statement
    
    def __repr__(self):
        statement = f"<Loan: {self.interest_rate}% on ${self.property_value} with {len(self.applicants)} applicant(s)>"
        return statement
    
    def yearly_amounts(self, yearly_payment):
        assert self.loan_amount > 0, f"Loan is paid off!"
        assert self.interest_rate > 0, f"Interest looks off..."
        amnt = self.loan_amount

        while amnt > 0:
            yield amnt
            new_amnt = amnt*(self.interest_rate / 100)+ amnt
            amnt = new_amnt - yearly_payment
        

with open("banks.json") as f:
    data = json.load(f)
    
# with ZipFile("wi.zip") as zf:
#     with zf.open("wi.csv", "r") as f:
    
class Bank:
    def __init__(self,bank):
        for dictionary in data:
            if dictionary["name"] == bank:
                self.lei = dictionary["lei"]
       
        self.loan_info = []   
        with ZipFile("wi.zip") as zf:
            with zf.open('wi.csv') as csv_file:
                tio = TextIOWrapper(csv_file)
                reader = csv.DictReader(tio)
                for val in reader:
                    if self.lei == val["lei"]:
                        self.loan_info.append(Loan(val))    
                        
    def __getitem__(self, key):
        item_idx = int(key)
        item = self.loan_info[item_idx]
        if type(key) == int:
            return self.loan_info[key]
        
        
    def __len__(self):
        return len(self.loan_info)
        
        

       